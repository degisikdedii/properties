# Product Properties Extension module

## About

Extends product properties and add support for products with fractional units of measurements (for example: weight, length, volume).
